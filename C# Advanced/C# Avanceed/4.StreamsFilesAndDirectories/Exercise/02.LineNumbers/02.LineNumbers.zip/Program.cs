﻿using System;

namespace LineNumbers
{
    using System;
    using System.IO;
    using System.Text;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"..\..\..\text.txt";
            string outputFilePath = @"..\..\..\output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            StringBuilder sb = new StringBuilder();

            using (StreamReader reader = new StreamReader(inputFilePath))
            {
                int lineNum = 0;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();

                    int lettersCount = 0;
                    int punctuationCount = 0;

                    foreach (char character in line)
                    {
                        if (char.IsLetter(character))
                        {
                            lettersCount++;
                        }
                        else
                        {
                            punctuationCount++;
                        }
                    }

                    string newLine = $"Line {++lineNum}: {line} ({lettersCount})({punctuationCount})";
                    sb.AppendLine(newLine);
                }
            }

            using (StreamWriter writer = new StreamWriter(outputFilePath))
            {
                writer.WriteLine(sb);
            }
        }
    }
}

